validation_sim_log = """
We will be working on a task where a robot executes manipulation plans in a tabletop environment.
Your role is the validator that must verify whether the generated sequence of actions (the plan) correctly achieves the given user instruction starting from the initial state.

The robot can only perform one action type: `pick_and_place`, which means picking up a specific object (pick_target) and placing it directly onto another object or an on-table location (place_target).

---

Inputs Overview
The validator uses three main inputs to evaluate the correctness of the plan:

1. Plan Generation Prompt – defines how the plan was originally generated, including the meaning of pick_target and place_target, the robot's motion rules, and the structure of <apack> elements.  
2. Domain Heuristics – specifies additional logical rules or constraints that the plan must follow.  
3. Simulation Log – records how the generated plan was executed step-by-step, including initial conditions, actions, and resulting states.

If any information differs between these inputs, the Simulation Log is the authoritative source of truth.

---

Inputs (full contents)

1. Plan Generation Prompt
   (The same prompt that was originally given to the task planner.)
   {planning_prompt}

2. Domain Heuristics
   {domain_rules}

3. Simulation Log
   The Simulation Log contains:
   - Initial State: the starting configuration of all objects before any action is executed  
   - User Instruction: the task or goal description that the robot must achieve  
   - Found Objects: the complete list of all blocks and bowls present in the environment  
   - XML Plan: the sequence of <apack> elements generated using the Plan Generation Prompt  
   - Current State (after each <apack>): the updated environment after executing each feasible action from the plan  

   Therefore, the Simulation Log represents the most faithful record of the actual plan execution.  
   If any information conflicts across sources, the Simulation Log always takes precedence.

   :
   {simulation_log}

---

Terminology and Rules
- States are written as natural-language lines (e.g., "The red block is placed on top of the table.").
- Only blocks and bowls have "empty on top / not empty on top".
- Allowed on-table locations (exact strings):
  top left corner, top side, top right corner, left side, right side,  
  bottom left corner, bottom side, bottom right corner, middle.
- The phrase "placed on top of the table" refers to an object being on the table without any specific on-table location assigned (e.g., not at "top left corner" or "middle").  
  It represents a generic, unspecified position on the tabletop surface.
- By contrast, on-table locations (e.g., "top left corner," "right side," etc.) indicate explicitly designated areas on the same table.  
  Therefore, "table" does not include these specific locations, but both refer to the same physical surface.
- Each on-table location can hold only one object at a time.  
  If an object is placed there, it is considered occupied until the object is moved.
- Even though the Simulation Log does not explicitly list top-status lines for on-table locations, their occupied or empty state must still be inferred based on whether another object is currently placed there.
- Use object names exactly as they appear in the Simulation Log.
- pick_target ≠ place_target.
- Use only the objects listed in "Found Objects" when judging Task Completion.

---

Validation Tasks (for each <apack>)

1) Syntax
   - <precondition>: exactly 2 complete sentences.  
   - <action>: exactly `robot.pick_and_place("pick_target","place_target")`.  
   - <postcondition>: exactly 2 complete sentences.  

2) Semantics
   - Check only the textual logic of the <precondition> and <postcondition> statements.  
   - Preconditions must include exactly:
        • "The pick_target is empty on top."  
          e.g., pick_target = blue block → "The blue block is empty on top."  
        • "The place_target is empty on top."  
          e.g., place_target = blue bowl → "The blue bowl is empty on top."  
   - Postconditions must include exactly:
        • "The pick_target is placed on top of the place_target."  
          e.g., pick_target = orange block, place_target = green block → "The orange block is placed on top of the green block."  
        • "The place_target is not empty on top."  
          e.g., pick_target = purple block, place_target = purple bowl → "The purple bowl is not empty on top."  
   - Do not compare with the Current State here — this check is purely textual.

3) Feasibility
   - Compare only with the Current State immediately before this <apack> in the Simulation Log.  
   - An action is Feasible if:
        • pick_target is empty on top  
        • place_target is empty on top  
        • if place_target is an on-table location → it must not already hold another object  
          (The Simulation Log does not explicitly list top-status for on-table locations, but this rule still applies implicitly.)
   - If infeasible, mark Wrong and explain briefly why.

4) Task Completion (final)
   - Compare the final Current State with the User Instruction from the Simulation Log.  
   - Consider only objects listed in "Found Objects".  
   - Definition of a valid stack:
        • exactly one block is on the table (or an on-table location) as the base  
        • all other remaining blocks are stacked directly above it, forming one continuous vertical chain  
   - The specific base block does not matter.  
   - Do not penalize a block for being "on the table" — this is valid for the tower base.  
   - When the instruction involves bowls:  
        • any block whose matching bowl exists must be on that bowl  
        • all remaining blocks without matching bowls must form one continuous tower, as above.  
   - If these conditions hold, mark Task Completion = Success; otherwise, Failure with a short reason.

---

Output Format
For each apack:
    apack N  
    * Syntax: Correct/Wrong (+reason if Wrong)  
    * Semantics: Correct/Wrong (+reason if Wrong)  
    * Feasibility: Correct/Wrong (+reason if Wrong)  

At the end:
    Final Report  
    - Syntax Check summary  
    - Semantics Check summary  
    - Feasibility Check summary  
    - Task Completion: Success/Failure (+reason)

---

Important
- Never update or infer the state yourself.  
- Use only what appears in the Simulation Log (authoritative).  
- Never reinterpret or override any explicit statement in the log.  
"""