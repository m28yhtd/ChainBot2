DOMAIN_PROMPT1 = """
We will be working on a task where a robotic arm moves objects in an environment like the one shown in the image.
Your role is to convert natural language commands into a form that the robot can understand and execute.

Each action must be expressed in XML format, using the following structure:
<plan>
    <sequence>
        <apack>
            <precondition>...</precondition>
            <precondition>...</precondition>
            <action>robot.pick_and_place("object", "destination")</action>
            <postcondition>...</postcondition>
            <postcondition>...</postcondition>
        </apack>
        ...
    </sequence>
</plan>

- Each <apack> block consists of:
    - Two <precondition> tags:
        - The top of the object to be picked (pick_target) must be empty.  
          (e.g., "The red block is empty on top.")
        - The top of the place_target must also be empty.  
          (e.g., "The yellow bowl is empty on top.")

    - One <action> tag using `robot.pick_and_place("pick_target", "place_target")`, where:
        - `"pick_target"` must be one of the objects listed in {found_objects}.
        - `"place_target"` can be:
            - one of the objects in {found_objects} (e.g., a bowl),
            - or one of the valid table placement locations listed below.

    - Two <postcondition> tags:
        - One confirming the pick_target was placed at the place_target.  
          (e.g., "The red block is placed on top of the yellow bowl.")
        - One confirming the place_target is no longer empty on top.  
          (e.g., "The yellow bowl is not empty on top.")

- Do not use symbols such as arrows (→) or shorthand notations. All relationships must be described in complete natural language sentences.

- Ensure that the final stack follows the target instruction precisely, and that all blocks are used according to domain rules.

- Valid Pick and Place Targets:
    - pick_target (objects only):  
      blue block, red block, green block, orange block, yellow block,  
      purple block, pink block, cyan block, brown block, gray block

    - place_target:
        - Objects or bowls in the environment:  
          blue block, red block, green block, orange block, yellow block, purple block, pink block, cyan block, brown block, gray block,
          blue bowl,red bowl,green bowl,orange bowl,yellow bowl,purple bowl,pink bowl,cyan bowl,brown bowl,gray bowl
        - Table-space anchors (always available):  
          top left corner, top side, top right corner,  
          left side, right side, bottom left corner, bottom side, bottom right corner

The following information is provided to support your generation:
    - Objects in the current environment: {found_objects}

Now, based on the above, convert the following natural language instruction into executable XML code:
{instruction}

Don't add any explanation—just output the converted plan.
Please respond like the examples. Do NOT use markdown or code blocks (e.g. no ```python).
"""

DOMAIN_PROMPT2 = """
We will be working on a task where a robotic arm moves objects in an environment like the one shown in the image.
Your role is to convert natural language commands into a form that the robot can understand and execute.

Each action must be expressed in XML format, using the following structure:
<plan>
    <sequence>
        <apack>
            <precondition>...</precondition>
            <precondition>...</precondition>
            <action>robot.pick_and_place("object", "destination")</action>
            <postcondition>...</postcondition>
            <postcondition>...</postcondition>
        </apack>
        ...
    </sequence>
</plan>

- Each <apack> block consists of:
    - Two <precondition> tags:
        - The top of the object to be picked (pick_target) must be empty.  
          (e.g., "The red block is empty on top.")
        - The top of the place_target must also be empty.  
          (e.g., "The yellow bowl is empty on top.")

    - One <action> tag using `robot.pick_and_place("pick_target", "place_target")`, where:
        - `"pick_target"` must be one of the objects listed in {found_objects}.
        - `"place_target"` can be:
            - one of the objects in {found_objects} (e.g., a bowl),
            - or one of the valid table placement locations listed below.

    - Two <postcondition> tags:
        - One confirming the pick_target was placed at the place_target.  
          (e.g., "The red block is placed on top of the yellow bowl.")
        - One confirming the place_target is no longer empty on top.  
          (e.g., "The yellow bowl is not empty on top.")

- Do not use symbols such as arrows (→) or shorthand notations. All relationships must be described in complete natural language sentences.

- Ensure that the final stack follows the target instruction precisely, and that all blocks are used according to domain rules.

- Valid Pick and Place Targets:
    - pick_target (objects only):  
      blue block, red block, green block, orange block, yellow block,  
      purple block, pink block, cyan block, brown block, gray block

    - place_target:
        - Objects or bowls in the environment:  
          blue block, red block, green block, orange block, yellow block, purple block, pink block, cyan block, brown block, gray block,
          blue bowl,red bowl,green bowl,orange bowl,yellow bowl,purple bowl,pink bowl,cyan bowl,brown bowl,gray bowl
        - Table-space anchors (always available):  
          top left corner, top side, top right corner,  
          left side, right side, bottom left corner, bottom side, bottom right corner

The following information is provided to support your generation:
    - Objects in the current environment: {found_objects}
    - Initial state: {initial_state}

Now, based on the above, convert the following natural language instruction into executable XML code:
{instruction}

Don't add any explanation—just output the converted plan.
Please respond like the examples. Do NOT use markdown or code blocks (e.g. no ```python).
"""

DOMAIN_PROMPT3 = """
We will be working on a task where a robotic arm moves objects in an environment like the one shown in the image.
Your role is to convert natural language commands into a form that the robot can understand and execute.

Each action must be expressed in XML format, using the following structure:
<plan>
    <sequence>
        <apack>
            <precondition>...</precondition>
            <precondition>...</precondition>
            <action>robot.pick_and_place("object", "destination")</action>
            <postcondition>...</postcondition>
            <postcondition>...</postcondition>
        </apack>
        ...
    </sequence>
</plan>

- Each <apack> block consists of:
    - Two <precondition> tags:
        - The top of the object to be picked (pick_target) must be empty.  
          (e.g., "The red block is empty on top.")
        - The top of the place_target must also be empty.  
          (e.g., "The yellow bowl is empty on top.")

    - One <action> tag using `robot.pick_and_place("pick_target", "place_target")`, where:
        - `"pick_target"` must be one of the objects listed in {found_objects}.
        - `"place_target"` can be:
            - one of the objects in {found_objects} (e.g., a bowl),
            - or one of the valid table placement locations listed below.

    - Two <postcondition> tags:
        - One confirming the pick_target was placed at the place_target.  
          (e.g., "The red block is placed on top of the yellow bowl.")
        - One confirming the place_target is no longer empty on top.  
          (e.g., "The yellow bowl is not empty on top.")

- Do not use symbols such as arrows (→) or shorthand notations. All relationships must be described in complete natural language sentences.

- Ensure that the final stack follows the target instruction precisely, and that all blocks are used according to domain rules.

- Valid Pick and Place Targets:
    - pick_target (objects only):  
      blue block, red block, green block, orange block, yellow block,  
      purple block, pink block, cyan block, brown block, gray block

    - place_target:
        - Objects or bowls in the environment:  
          blue block, red block, green block, orange block, yellow block, purple block, pink block, cyan block, brown block, gray block,
          blue bowl,red bowl,green bowl,orange bowl,yellow bowl,purple bowl,pink bowl,cyan bowl,brown bowl,gray bowl
        - Table-space anchors (always available):  
          top left corner, top side, top right corner,  
          left side, right side, bottom left corner, bottom side, bottom right corner

The following information is provided to support your generation:
    - Objects in the current environment: {found_objects}
    - Example plan: {example}
    - Initial state: {initial_state}

Now, based on the above, convert the following natural language instruction into executable XML code:
{instruction}

Don't add any explanation—just output the converted plan.
Please respond like the examples. Do NOT use markdown or code blocks (e.g. no ```python).
Just return the response like examples.
"""

DOMAIN_PROMPT4 = """
We will be working on a task where a robotic arm moves objects in an environment like the one shown in the image.
Your role is to convert natural language commands into a form that the robot can understand and execute.

Each action must be expressed in XML format, using the following structure:
<plan>
    <sequence>
        <apack>
            <precondition>...</precondition>
            <precondition>...</precondition>
            <action>robot.pick_and_place("object", "destination")</action>
            <postcondition>...</postcondition>
            <postcondition>...</postcondition>
        </apack>
        ...
    </sequence>
</plan>

- Each <apack> block consists of:
    - Two <precondition> tags:
        - The top of the object to be picked (pick_target) must be empty.  
          (e.g., "The red block is empty on top.")
        - The top of the place_target must also be empty.  
          (e.g., "The yellow bowl is empty on top.")

    - One <action> tag using `robot.pick_and_place("pick_target", "place_target")`, where:
        - `"pick_target"` must be one of the objects listed in {found_objects}.
        - `"place_target"` can be:
            - one of the objects in {found_objects} (e.g., a bowl),
            - or one of the valid table placement locations listed below.

    - Two <postcondition> tags:
        - One confirming the pick_target was placed at the place_target.  
          (e.g., "The red block is placed on top of the yellow bowl.")
        - One confirming the place_target is no longer empty on top.  
          (e.g., "The yellow bowl is not empty on top.")

- Do not use symbols such as arrows (→) or shorthand notations. All relationships must be described in complete natural language sentences.

- Ensure that the final stack follows the target instruction precisely, and that all blocks are used according to domain rules.

- Valid Pick and Place Targets:
    - pick_target (objects only):  
      blue block, red block, green block, orange block, yellow block,  
      purple block, pink block, cyan block, brown block, gray block

    - place_target:
        - Objects or bowls in the environment:  
          blue block, red block, green block, orange block, yellow block, purple block, pink block, cyan block, brown block, gray block,
          blue bowl,red bowl,green bowl,orange bowl,yellow bowl,purple bowl,pink bowl,cyan bowl,brown bowl,gray bowl
        - Table-space anchors (always available):  
          top left corner, top side, top right corner,  
          left side, right side, bottom left corner, bottom side, bottom right corner

The following information is provided to support your generation:
    - Objects in the current environment: {found_objects}
    - Initial state: {initial_state}
    - Domain rules: {domain_rules}

Now, based on the above, convert the following natural language instruction into executable XML code:
{instruction}

Don't add any explanation—just output the converted plan.
Please respond like the examples. Do NOT use markdown or code blocks (e.g. no ```python).
"""

DOMAIN_PROMPT5 = """
We will be working on a task where a robotic arm moves objects in an environment like the one shown in the image.
Your role is to convert natural language commands into a form that the robot can understand and execute.

Each action must be expressed in XML format, using the following structure:
<plan>
    <sequence>
        <apack>
            <precondition>...</precondition>
            <precondition>...</precondition>
            <action>robot.pick_and_place("object", "destination")</action>
            <postcondition>...</postcondition>
            <postcondition>...</postcondition>
        </apack>
        ...
    </sequence>
</plan>

- Each <apack> block consists of:
    - Two <precondition> tags:
        - The top of the object to be picked (pick_target) must be empty.  
          (e.g., "The red block is empty on top.")
        - The top of the place_target must also be empty.  
          (e.g., "The yellow bowl is empty on top.")

    - One <action> tag using `robot.pick_and_place("pick_target", "place_target")`, where:
        - `"pick_target"` must be one of the objects listed in {found_objects}. (except bowl)
        - `"place_target"` can be:
            - one of the objects in {found_objects} (e.g., a bowl),
            - or one of the valid table placement locations listed below.

    - Two <postcondition> tags:
        - One confirming the pick_target was placed at the place_target.  
          (e.g., "The red block is placed on top of the yellow bowl.")
        - One confirming the place_target is no longer empty on top.  
          (e.g., "The yellow bowl is not empty on top.")

- Do not use symbols such as arrows (→) or shorthand notations. All relationships must be described in complete natural language sentences.

- Ensure that the final stack follows the target instruction precisely, and that all blocks are used according to domain rules.

- Valid Pick and Place Targets:
    - pick_target (objects only):  
      blue block, red block, green block, orange block, yellow block,  
      purple block, pink block, cyan block, brown block, gray block

    - place_target:
        - Objects or bowls in the environment:  
          blue block, red block, green block, orange block, yellow block, purple block, pink block, cyan block, brown block, gray block,
          blue bowl,red bowl,green bowl,orange bowl,yellow bowl,purple bowl,pink bowl,cyan bowl,brown bowl,gray bowl
        - Table-space anchors (always available):  
          top left corner, top side, top right corner,  
          left side, right side, bottom left corner, bottom side, bottom right corner

The following information is provided to support your generation:
    - Objects in the current environment: {found_objects}
    - Example plan: {example}
    - Initial state: {initial_state}
    - Domain rules: {domain_rules}

Now, based on the above, convert the following natural language instruction into executable XML code:
{instruction}

Don't add any explanation—just output the converted plan.
Please respond like the examples. Do NOT use markdown or code blocks (e.g. no ```python).
Just return the response like examples.
"""